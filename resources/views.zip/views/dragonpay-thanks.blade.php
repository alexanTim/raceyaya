@extends('layouts.app')

@section('content')
<div class="container">

       

		    <div class="row justify-content-center" style="padding-top:37px;margin-bottom: 70px;">
				<div style="padding-top: 42px;" class="thankyou-box col-md-12">						
                    <h1 style="font-size: 26px;font-weight: bold;">Thank your for paying through raceyaya payment portal.</h1>
                    <p style="text-align: justify;margin-top: 41px;padding-bottom: 65px;">
                        The organizer will review your uploaded file and will update your status to complete. If you 
                        comply all the requirements. 
                    </p>                      
                    <p style="background:#eee; padding:10px;">    <span ><STRONG>REFNO: </STRONG> <strong><?PHP echo $_GET['refno'];?> </strong></span></p>
                        <br/><br/>
                     <p>   <span>Thanks for your time.</span></p>
                    </p>
                </div>
			</div>

    </div>
@endsection
