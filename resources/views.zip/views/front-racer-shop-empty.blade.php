@extends('layouts.app')
@section('content')
<div class="container">
	<div class="row">
		<div style="text-align: center;color: red;font-size: 16pt;" class="col-md-12 heading_row">
			<p>You are not registered to this event.</p>
		</div>
	</div>
</div>
@endsection