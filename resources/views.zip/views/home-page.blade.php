@extends('layouts.app')
@section('content')
<div class="live-race-section">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div id="owl-race" class="owl-carousel owl-theme">
					<div class="live-race">
						<div class="live-race-thumb"><img src="{{ asset('public/img/live-race-1.jpg') }}" width="100%" class="img-responsive"></div>
						<div class="live-race-info">
							<h5>Live Race</h5>
							<h3>Beach Marathon</h3>
							<a href="#" class="btn">FOLLOW</a>
						</div>
					</div>
					<div class="live-race">
						<div class="live-race-thumb"><img src="{{ asset('public/img/live-race-2.jpg') }}" width="100%" class="img-responsive"></div>
						<div class="live-race-info">
							<h5>Live Race</h5>
							<h3>Beach Marathon</h3>
							<a href="#" class="btn">FOLLOW</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-12 row2">
				<h2>For RaceYaYa <strong>Racers & Fans</strong></h2>
				<p>Endurance Athletes / RaceYaya supports the journey of every endurance athlete. Find and registerfor a race now, get ready: shop and train, track your race progress and results.</p>
				<a href="#" class="btn">SEE MORE</a>
			</div>
			<div class="col-lg-12 row3">
				<div id="owl-events" class="owl-carousel owl-theme owl-events">
					<div class="block">
						<div class="block-thumb"><img src="{{ asset('public/img/event1.jpg') }}" width="100%" class="img-responsive"></div>
						<div class="block-info">
							<h4>Find Event Registrations</h4>
							<p>yourRaceYaya is the registration portal for endurance sports: from road, to skyrunning to trail running, sprint to 5K to ultra distances, triathlon, aquathlon to duathlon and other multisports races.</p>
							<a href="#" class="btn">Register Now</a>
						</div>
					</div>
					<div class="block">
						<div class="block-thumb"><img src="{{ asset('public/img/event2.jpg') }}" width="100%" class="img-responsive"></div>
						<div class="block-info">
							<h4>Find Event Race Profiles</h4>
							<p>yourRaceYaya is a community of endurance athletes. Check out who are #yourRaceYaya, their upcoming races and past race results.</p>
							<a href="#" class="btn">Register Now</a>
						</div>
					</div>
					<div class="block">
						<div class="block-thumb"><img src="{{ asset('public/img/event3.jpg') }}" width="100%" class="img-responsive"></div>
						<div class="block-info">
							<h4>Find Race Results</h4>
							<p>your RaceYaya is a host to endurance races powered by RaceYaya Timing Solutions and other partner timing providers. Review past performances in multitude of sports. Preview your past results and add them to your profile.</p>
							<a href="#" class="btn">Register Now</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-12 row4">
				<div class="block">
					<div class="content">
						<h2>RaceYaya <strong>Solutions</strong></h2>
						<p>Et cillum in id amet. Voluptate dolor enim sit minim, anim dolor, irure reprehenderit occaecat enim, nostrud.</p>
						<a href="#" class="btn">READ MORE</a>
					</div>
					<div class="blockimg text-center">
						<img src="{{ asset('public/img/timing.jpg') }}" width="100%" class="img-responsive">
						<p>TIMING</p>
					</div>
				</div>
			</div>
			<div class="col-lg-12 row2 row5">
				<h2>For Event <strong>Organizers</strong></h2>
				<p>Organizers / RaceYaya provides a comprehensive registration and timing solutions that is suited for race organizers of different endurance sports and varying numbers of participants.</p>
				<a href="#" class="btn">KNOW MORE</a>
			</div>
			<div class="col-lg-12 row3 row6">
				<div id="owl-events2" class="owl-carousel owl-theme owl-events">
					<div class="block">
						<div class="block-thumb"><img src="{{ asset('public/img/img-2.jpg') }}" width="100%" class="img-responsive"></div>
						<div class="block-info">
							<h4>Event Registrations</h4>
							<p>Through our website race registration, steps and procedures are seamless and are automatically available for feedback and viewing both for athletes and organizers.</p>
							<a href="#" class="btn">Register Now</a>
						</div>
					</div>
					<div class="block">
						<div class="block-thumb"><img src="{{ asset('public/img/img-1.jpg') }}" width="100%" class="img-responsive"></div>
						<div class="block-info">
							<h4>RaceYaya Timing Solutions</h4>
							<p>RaceYaya Timing Solutions provides a complete race results hosting, timing and finish line services.</p>
							<a href="#" class="btn">Register Now</a>
						</div>
					</div>
					<div class="block">
						<div class="block-thumb"><img src="{{ asset('public/img/img-3.jpg') }}" width="100%" class="img-responsive"></div>
						<div class="block-info">
							<h4>Race Results</h4>
							<p>Tempor non amet cillum voluptate occaecat do cillum consequat dolore consequat.</p>
							<a href="#" class="btn">Register Now</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-12 row3 row7">
				<div style="position: relative;background: #f2f2;/*! width: 500px; */top: 0px;height: 12px;margin-left: 24px;margin-right: 20px;"></div>
				<div id="owl-latest-events" class="owl-carousel home-latest-event">
					<div class="block">
							<figure class="latest-event-thumb"> <img src="{{ asset('images/clark-triathlon-classic.jpg') }}" width="100%" class="img-responsive"> </figure>
							<div class="content">
								<h2>Latest Event</h2>
								<h3 class="latest-event-title">2019 CLARK TRIATHLON CLASSIC </h3>
								<p>Nulla incididunt ut amet consequat amet aute et enim, officia culpa. Do commodo culpa incididunt nostrud, elit commodo in sed.</p>
								<a href="#">READ MORE</a>
							</div>
					</div>
					<div class="block">
							<figure class="latest-event-thumb"> <img src="{{ asset('images/clark-triathlon-classic.jpg') }}" width="100%" class="img-responsive"> </figure>
							<div class="content">
								<h2>Latest Event</h2>
								<h3 class="latest-event-title">2019 CLARK TRIATHLON CLASSIC </h3>
								<p>Nulla incididunt ut amet consequat amet aute et enim, officia culpa. Do commodo culpa incididunt nostrud, elit commodo in sed.</p>
								<a href="#">READ MORE</a>
							</div>
					</div>
				</div>
				<div style="position: relative;background: #f2f2;/*! width: 500px; */top: 0px;height: 12px;margin-left: 24px;margin-right: 20px;"></div>
			</div>
			<div class="col-lg-12 row6 feedback-blog-con">
				<div class="feedback">
					<h2 class="hdr">Feedback <strong>Happy Clients</strong> </h2>
					<div id="owl-home-feedback" class="owl-carousel">
						<div class="block">
							<div class="author">
								<figure> <img src="{{ asset('public/img/feedback-author-thumb.png') }}" alt="" style="border-radius:100%"> </figure>
								<h3>Julian Snow</h3>
								<span class="career">- Graphic Designer</span>
							</div>
							<div class="content">
								<figure class="qoute-icon"> <img src="{{ asset('images/feedback-qoute-icon.png') }}" alt=""> </figure>
								<p>Ut officia sint occaecat tempor cillum occaecat. Reprehenderit et amet veniam exercitation nulla ipsum ullamco exercitation excepteur ex deserunt reprehenderit non reprehenderit excepteur ullamco. Non veniam commodo do enim nulla do adipisicing ut labore, consectetur minim cillum aliqua exercitation sunt veniam.</p>
							</div>
						</div>
						<div class="block">
							<div class="author">
								<figure> <img src="{{ asset('public/img/feedback-author-thumb-2.png') }}" alt=""> </figure>
								<h3>Julian Snow</h3>
								<span class="career">- Graphic Designer</span>
							</div>
							<div class="content">
								<figure class="qoute-icon"> <img src="{{ asset('images/feedback-qoute-icon.png') }}" alt=""> </figure>
								<p>Ut officia sint occaecat tempor cillum occaecat. Reprehenderit et amet veniam exercitation nulla ipsum ullamco exercitation excepteur ex deserunt reprehenderit non reprehenderit excepteur ullamco. Non veniam commodo do enim nulla do adipisicing ut labore, consectetur minim cillum aliqua exercitation sunt veniam.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="home-blog">
					<h2 class="hdr">Latest <strong>Blog Post</strong> </h2>
					<a href="#" class="see-more">SEE MORE</a>
					<div class="home-blogs-container">
						<div class="home-blogs">
							<figure> <img src="{{ asset('public/img/blog-thumb1.jpg') }}" alt=""> </figure>
							<div class="content">
								<h3 class="title">Sample Title Here</h3>
								<p>Dolor ea consequat magna officia dolore consequat ut cillum .</p>
								<a href="#">Read More</a>
							</div>
						</div>
						<div class="home-blogs">
							<figure> <img src="{{ asset('public/img/blog-thumb2.jpg') }}" alt=""> </figure>
							<div class="content">
								<h3 class="title">Sample Title Here</h3>
								<p>Dolor ea consequat magna officia dolore consequat ut cillum .</p>
								<a href="#">Read More</a>
							</div>
						</div>
						<div class="home-blogs">
							<figure> <img src="{{ asset('public/img/blog-thumb3.jpg') }}" alt=""> </figure>
							<div class="content">
								<h3 class="title">Sample Title Here</h3>
								<p>Dolor ea consequat magna officia dolore consequat ut cillum .</p>
								<a href="#">Read More</a>
							</div>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>
@endsection
