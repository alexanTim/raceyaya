@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        
		<h1>Your content here homepage </h1>
        <h1>Found /resources/views/home.blade.php </h1>
    </div>
			

</div>
@endsection
