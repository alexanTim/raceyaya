@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
		<div class="social" class="col-md-8" style="text-align:center;">
					<img  src="{{ asset('images/check.png') }}"/>
		</div>
	</div>

		    <div class="row justify-content-center">
				<div class="col-md-9" style="text-align:center;text-align: center;padding: 58px;box-shadow: 3px 3px 4px -1px #eee;min-height: 234px;">						
						<h1> Jeff test blade</h1>
						
				</div>
			</div>

    </div>
@endsection
