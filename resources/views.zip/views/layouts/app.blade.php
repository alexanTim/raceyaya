<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Raceyaya') }}</title>

    <!-- Scripts -->

    <script src="{{ asset('js/jquery.selectric.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/selectric.css') }}" rel="stylesheet">
    <link href="{{ asset('css/home_css.css') }}" rel="stylesheet">
    <link href="{{ asset('css/owl.carousel.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/owl.theme.default.min.css') }}" rel="stylesheet">

	<link href="{{ asset('css/sweetalert2.min.css') }}" rel="stylesheet">
	<script src="{{ asset('js/sweetalert2.min.js') }}"></script>	
    <link href="{{ asset('css/timepicki.css') }}" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700,800,900&display=swap" >
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>

</head>
<body ng-url="{{config('app.url')}}" >
    <div id="app">   
		<div @if(!empty($whatpage)) class="__header_about" @else class="__header"@endif>
			<nav class="navbar navbar-expand-md navbar-light shadow-sm top-menu">
				<div class="container">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->

					<span class="social_logo" ><img style="width: 13px;" src="{{ asset('images/h-icon-fb.png') }}"/></span>
					<span class="social_logo"> <img style="width: 13px;" src="{{ asset('images/h-icon-yt.png') }}"/></span>
					<span class="social_logo" ><img style="width: 13px;" src="{{ asset('images/h-icon-g.png') }}"/></span>
					<span class="social_logo" ><img style="width: 13px;" src="{{ asset('images/h-icon-ins.png') }}"/></span>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->

                        @guest
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('create_account') }}">{{ __('Signup') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item">
                               		<a class="-item  @if(Route::currentRouteName() == 'profile') ry_navmain_current @endif" href="{{ route('profile') }}">
                                        <?php 
                                           echo (Auth::user()->firstname =='') ? ucfirst(Auth::user()->name) : ucfirst(Auth::user()->firstname);
                                        ?>
                                    </a>&nbsp;|&nbsp;
 									<a class="-item" href="{{ route('logout') }}">
                                      Logout
                                    </a>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        
        <nav class="navbar navbar-expand-md navbar-light  shadow-sm menu-racenave">
         
          <span><img width="30%" src="{{ asset('images/h-Iogo.png') }}"/></span>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
					          
                    <!-- Right Side Of Navbar -->
             <ul class="navbar-nav ml-auto">
              <!-- Authentication Links -->
							<li class="nav-item">
                  <a class="nav-link  @if(Route::currentRouteName() == 'home') ry_navmain_current @endif" href="{{ route('home') }}">{{ __('Home') }}</a>
              </li>
							<li class="nav-item">               
                  <a class="nav-link  @if(Route::currentRouteName() == 'about') ry_navmain_current @endif"  href="{{ route('about') }}">{{ __('About') }}</a>
              </li>
							<li class="nav-item">
                    <a class="nav-link  @if(Route::currentRouteName() == 'front-racer') ry_navmain_current @endif" href="{{ route('front-racer') }}">{{ __('Races') }}</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link  @if(Route::currentRouteName() == 'racers-list') ry_navmain_current @else  @if(Route::currentRouteName() == 'getPublicProfile') ry_navmain_current @endif @endif"  href="{{ route('racers-list') }}">{{ __('Racers') }}</a>
              </li>
							<li class="nav-item">
                  <a class="nav-link  @if(Route::currentRouteName() == 'blog') ry_navmain_current @endif" href="{{ route('blog') }}">{{ __('Resources') }}</a>
              </li>
							<li class="nav-item">
                 <a class="nav-link @if(Route::currentRouteName() == 'Organizers') ry_navmain_current @endif" href="{{ route('Organizers') }}">{{ __('Organizers') }}</a>
              </li>
							<li class="nav-item">
                 <a class="nav-link  @if(Route::currentRouteName() == 'Contact') ry_navmain_current @endif" href="{{ route('Contact') }}">{{ __('Contact') }}</a>
              </li>
              </ul>
                </div>
               
        </nav>

        @if(Route::currentRouteName() == 'home')
          <div class="banner-section">
            <div class="container">
              <div class="slogan">
                <h2>Welcome to</h2>
                <figure> <img src="{{ asset('images/h-Iogo.png') }}" alt="raceyaya"> </figure>
                <!-- <p>Find a Race . Organizer a Race . Time a Race . Get Race Ready</p>--> 
                <a style="color:white;" class="button secondary url common_banner_class zero2" href="#zero">Time a Race.</a> 
                <a style="color:white;" class="button secondary url common_banner_class one3" href="#one">Find A Race.</a> 
                <a style="color:white;" class="button secondary url common_banner_class two4" href="#two">Organizer a Race.</a>
                <a style="color:white;" class="button secondary url common_banner_class three5" href="#three"> Get Race Ready</a>
                <ul>
                    <li><a href="#">Shop</a></li>
                    <li><a href="#">Register</a></li>
                    <li><a href="#">Time</a></li>
                </ul>
              </div>            
            </div> 

            <div id="owl-demo333" class="owl-carousel owl-theme owlcarousel_home">                 
              <div  data-hash="zero"  class="item"><img  style="height:600px;" src="{{asset('images/ty-timing.jpeg')}}" alt="The Last of us"></div>
              <div  data-hash="one"   class="item"><img  style="height:600px;" src="{{asset('images/ty-find-race.jpeg')}}" alt="GTA V"></div>
              <div  data-hash="two"   class="item"><img  style="height:600px;" src="{{asset('images/Event-Registrations.jpeg')}}" alt="Mirror Edge"></div>
              <div  data-hash="three" class="item"><img  style="height:600px;" src="{{asset('images/Find-Event-Registrations.jpeg')}}" alt="Mirror Edge"></div>
            </div>
            @if(!$all->isEmpty())
              <div class="upcoming-race">
                <div id="owl-upcoming-race" class="owl-carousel owl-theme">
                  @foreach($all as $item)
                    <div class="content">
                        <div class="left" style="width: 55%;">
                          <h2>Upcoming Race<span>{{$item->event_name}}</span> </h2>
                          <a href="#">Register Here</a>
                        </div>                      
                        <div class="right" style="width: 45%;"> 
                          <div class="flex-w flex-c cd100 p-b-82" data-countdown="{{$item->event_date_race}}">
                          <!-- <div class="flex-col-c-m"><div class="how-countdown"><span class="l1-txt3 p-b-9">%D</span> </div><span class="s1-txt1">Days</span></div><span class="semi">:</span>
                          <div class="flex-col-c-m"><div class="how-countdown"><span class="l1-txt3 p-b-9">%H</span> </div><span class="s1-txt1">Hour</span></div><span class="semi">:</span>
                          <div class="flex-col-c-m"><div class="how-countdown"><span class="l1-txt3 p-b-9">%M</span> </div><span class="s1-txt1">Minutes</span></div><span class="semi">:</span>
                          <div class="flex-col-c-m"><div class="how-countdown"><span class="l1-txt3 p-b-9">%S</span> </div><span class="s1-txt1">Seconds</span></div> -->
                          </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                  @endforeach
                </div>
              </div>
            @endif

          </div>

        @endif

	   </div>
<!-- 
<div class="content">
                  <div class="left">
                    <h2>Upcoming Race<span>Impasugong Ridge Marathon</span> </h2>
                    <a href="#">Register Here</a>
                  </div>
                  <div class="right">
                    <img src="asset('images/upcoming-race-timer.png') }}" alt="">
                  </div>
                  <div class="clearfix"></div>
                </div>
-->
   
 	   @if(!empty($whatpage))
	   		<main class="py-4" style="background: #F2F2F2">
	            @yield('content')
	        </main>

	   @else
			<main class="py-4">
	            @yield('content')
	        </main>
	   @endif



		<div id="footer" class="container-fluid footer mt-5">
			 <div class="container">
				 <div class="row upper">
					<div class="col-md-6 top-subscribe" style="">
						<span style="color:#fff;font-size:25px;color:#fff">SUBSCRIBE TO OUR </span><span style="font-size:25px;color:#64c0ff">NEWSLETTER</span>
						<p>Be the first to get the latest update and promos</p>
					</div>
					<div class="col-md-6  top-subscribe" style="padding-right:0px;">
						<input style="margin-left: 19px;" class="input_type" type="text" style="" name="subscribe"/><a style="position: relative !important;top: 0px !important;" class="subs btn btn-primary">Subscribe Now</a>
					</div>

				</div>
				<div class="row justify-content-center" style="padding-top: 51px;padding-bottom: 51px;">
					<div class="col-md-4" style="text-align:center">
						<img width="60%" src="{{ asset('images/h-Iogo.png') }}"/>
						<div class="social_footer" style="padding-top: 12px;">
						<span class="social_logo" style="padding-right: 4px;" ><img style="width: 5%;" src="{{ asset('images/h-icon-fb.png') }}"/></span>
						<span class="social_logo" style="padding-right:10px;"> <img style="width: 7%;" src="{{ asset('images/h-icon-yt.png') }}"/></span>
						<span class="social_logo" style="padding-right: 10px;"><img style="width: 6%;" src="{{ asset('images/h-icon-g.png') }}"/></span>
						<span class="social_logo" ><img style="width: 6%;" src="{{ asset('images/h-icon-ins.png') }}"/></span>
						</div>
					</div>
				</div>

				<div class="row" style="padding-top: 51px;padding-bottom: 51px;">
					<div class="col-md-5 float-left" style="text-align:left">
						&#169; 2019 <strong style="color:#fff">Raceyaya</strong> - All Rights Reserved - Powered by <strong style="color:#fff">Panalo</strong>
					</div>

					<div class="col-md-7  float-left" style="text-align:right">
						 <ul class="list-inline">
							 <li class="list-inline-item"><a href="javascript:void(0)">Term of Service</a></li>
							 <li class="list-inline-item"><a href="{{ route('about') }}">About Us</a></li>
							 <li class="list-inline-item">Solutions</li>
							 <li class="list-inline-item"><a href="{{ route('Contact') }}">Contact Us</a></li>
						 </ul>
					</div>
				</div>
			</div> <!-- Close Container -->
    </div> <!-- Close footer  -->
    
    @include('modal');
    

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  
   <!-- 1 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> --> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
  <script src="{{asset('js/datepicker3/moment.js') }}"></script>
  <link rel="stylesheet" href="{{asset('js/datepicker3/bootstrap-datetimepicker.min.css') }}" type="text/css" media="all" />
  <script type="text/javascript" src="{{asset('js/datepicker3/bootstrap-datetimepicker.min.js') }}"></script>
  
  <script src="{{ asset('js/owl.carousel.min.js') }}"></script>
  <script src="{{ asset('js/timepicki.js') }}"></script>
  
  <script src="{{ asset('js/race_app.js') }}" defer></script>

  <script src="{{ asset('js/drop.js') }}" defer></script>
 
  <link href="{{ asset('css/dropzone.min.css') }}" rel="stylesheet">
  <script src="{{ asset('js/dropzone.min.js') }}"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
  <script src="//cdn.rawgit.com/hilios/jQuery.countdown/2.2.0/dist/jquery.countdown.min.js"></script> 
  <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

  <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
  <script type="text/javascript">
      CKEDITOR.replace('event_description', {
          filebrowserUploadUrl: "{{route('ckeditor.upload', ['_token' => csrf_token() ])}}",
          filebrowserUploadMethod: 'form'
      });
  </script>
  
  <!--  COMMON JAVASCRIPT INTEGRATION GOES HERE -->
  <script src="{{ asset('js/common.js') }}" defer></script>
  <script>
  $(document).ready(function()
  {        
    $('#owl-upcoming-race').owlCarousel({
      stagePadding: 350,
      items: 1,
      loop: false,
      margin: 10,
      nav: false
    });  

  // var nice = $("#oraganizer_term_and_condi .organizer_term_insert").niceScroll();
  /*
  $('[data-countdown]').each(function() {
  var $this = $(this), finalDate = $(this).data('countdown');
  $this.countdown(finalDate, function(event) {
  $this.html(event.strftime(
  '<div class="flex-col-c-m"><div class="how-countdown"><span class="l1-txt3 p-b-9">%D</span> </div><span class="s1-txt1">Days</span></div><span class="semi">:</span>'+
  '<div class="flex-col-c-m"><div class="how-countdown"><span class="l1-txt3 p-b-9">%H</span> </div><span class="s1-txt1">Hour</span></div><span class="semi">:</span>'+
  '<div class="flex-col-c-m"><div class="how-countdown"><span class="l1-txt3 p-b-9">%M</span> </div><span class="s1-txt1">Minutes</span></div><span class="semi">:</span>'+
  '<div class="flex-col-c-m"><div class="how-countdown"><span class="l1-txt3 p-b-9">%S</span> </div><span class="s1-txt1">Seconds</span></div>'
  ));
  });
  });
  */
  })
  </script>
  <script >
    (function($){
      $(function(){      
          $('.expiration_date_cvv').datetimepicker({               
              "format": "MM/YY",
          });
          /*$('.common_date_picker').datetimepicker({               
              "format": "MM/DD/YYYY",
          });*/
          $('.coupon_expiry_date').datetimepicker({               
              "format": "MM/DD/YYYY",
          });
      });
    })(jQuery);

    $(document).ready(function(){
        $('body').on('focus',".common_date_picker", function(){
            $(this).datetimepicker({               
              format: "MM/DD/YYYY",
              minDate: moment()
            }).on('keypress paste',function(e){
              e.preventDefault();
              return false;
            })
        });

      
        
    })
  </script>
   
    <!-- <script src="mix('js/bootstrap.js')}}"></script><script src="mix('js/app.js') }}"></script>-->
  <script>
        $(function() {
          /* Dark Thin */
          $("#oraganizer_term_and_condi .modal-body,#term_and_condition_racer_reg_ .modal-body").mCustomScrollbar({
            theme: "3d-dark"
          });
        });
      </script>
      
  <style>
    .flex-c {
        justify-content: center;
    }
    .flex-w{
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
    }
    .semi{
      font-size: 53px;
        /* display: flex; */
        color: #7F7F7F;
        font-weight: bold;
    }

    .how-countdown {
      background-color: #7F7F7F;
      border-radius: 7px;
      margin: 0px 8px 0px 10px;
      width: 75px;
      height: 79px;
      text-align: center;
      padding-top: 20px;
    }

    .l1-txt3 {
        font-family: Montserrat-Bold;
        font-size: 45px;
        color: #fff;
        line-height: 1;
        font-weight: bold;
    }
    .p-b-9 {
        padding-bottom: 9px;
    }
    .flex-col-c-m {
        -ms-align-items: center;
        align-items: center;
        justify-content: center;
    }
    
    .s1-txt1 {
      font-family: Montserrat-Regular;
        font-size: 18px;
        color: #7F7F7F;
        text-transform: uppercase;
        text-align: center;
        width: 90px;
        display: block;
    }
  </style>

      <style type="text/css">
        body{overflow:auto;}


        .accordion-container{
	position: relative;	
	height: auto;
	margin: 10px auto;
  }
  .accordion-container > h2{
	text-align: center;
	color: #fff;
	padding-bottom: 5px;
	margin-bottom: 20px;
	padding-bottom: 15px;
	border-bottom: 1px solid #ddd;
  }
  .set{
	position: relative;
	width: 100%;
	height: auto;
	background-color: #f5f5f5;
  }
  .set > a{
	display: block;
	padding: 23px 15px;
	text-decoration: none;
	color: #555;
	font-weight: 600;
	border-bottom: 1px solid #ddd;
	-webkit-transition:all 0.2s linear;
	-moz-transition:all 0.2s linear;
	transition:all 0.2s linear;
  }
  .set > a i{
	float: right;
	margin-top: 2px;
  }
  .set > a.active{
	background-color:#64C0FF;
	color: #fff;
  }
  
  
  .content_accord{
	background-color: #fff;
	border-bottom: 1px solid #ddd;
	display:none;
  }
  .content_accord p{
	padding: 10px 15px;
	margin: 0;
	color: #333;
  }
      </style>
	  
	 <script>
     $(document).ready(function() {
  $(".set > a").on("click", function() {
    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
      $(this)
        .siblings(".content_accord")
        .slideUp(200);
      $(".set > a i")
        .removeClass("fa-minus")
        .addClass("fa-plus");
    } else {
      $(".set > a i")
        .removeClass("fa-minus")
        .addClass("fa-plus");
      $(this)
        .find("i")
        .removeClass("fa-plus")
        .addClass("fa-minus");
      $(".set > a").removeClass("active");
      $(this).addClass("active");
      $(".content_accord").slideUp(200);
      $(this)
        .siblings(".content_accord")
        .slideDown(200);
    }
  });
});

   </script>
     </body>
</html>