@extends('layouts.app')

@section('content')


<div class="container">
	<div class="row">
		<div class="col-md-12 heading_row">
		<h3>Thank you</h3>
		</div>
	</div>
</div>


<div class="container">	
	<div class="row">	
		<div class="col-md-12" style="padding: 41px;text-align: center;background: #fff;box-shadow:1px 27px 32px 4px #f9f9f9;margin-top: 113px;">	
		    <h2>Successfully submitted</h2>
   		</div>	
	</div>	
</div>
@endsection

