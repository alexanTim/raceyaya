@extends('layouts.app')

@section('content')
<div class="container">

       

		    <div class="row justify-content-center" style="padding-top:37px;margin-bottom: 70px;">
				<div class="thankyou-box col-md-9" style="">						
						<h1>Thank your for updating the requirement for the  event registration.</h1>
                        <p style="text-align: center;">
                            The organizer will review your uploaded file and will update your status to complete. If you 
                            comply all the requirements. 
							<br/>
							<span>Thanks for your time.</span>
						</p>
				</div>
			</div>

    </div>
@endsection
