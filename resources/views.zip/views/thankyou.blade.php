@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
		<div class="social" class="col-md-8" style="text-align:center;">
					<img  src="{{ asset('images/check.png') }}"/>
		</div>
	</div>

		    <div class="row justify-content-center" style="margin-bottom: 70px;">
				<div class="thankyou-box col-md-9" style="">						
						<h1>Thank Your For Signing Up!</h1>
						<p style="text-align: justify;">
							#yourRaceYaya account will give you access to create your events and races, online shop for gears and
							nutrition for your participants, time your participants and post race results, reach out to a community of
							endurance athletes. Welcome to #yourRaceYaya
							<br/>
							<span></span>
						</p>
						<button class="btn btn-primary find_out_more btn_common">Find Out More</button>
				</div>
			</div>

    </div>
@endsection
